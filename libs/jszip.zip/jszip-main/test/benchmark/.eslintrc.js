"use strict";

module.exports = {
    globals: {
        // Added by index.html and node.js
        Benchmark: false,
    },
};
