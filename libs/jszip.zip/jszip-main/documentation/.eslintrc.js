"use strict";

module.exports = {
    globals: {
        $: false,
        jQuery: false,
        JSZip: false,
        JSZipUtils: false,
        // From FileSaver.js
        saveAs: false,
    },
};
