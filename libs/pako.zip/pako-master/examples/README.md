Demo of sending compressed objects from browser to server.

Run `node server.js` and open `browser.html`.

__Warning!__ This is the sample only, to show data reencoding steps. It does
not have error checks and so on. Don't copy-paste to production code "as is".
